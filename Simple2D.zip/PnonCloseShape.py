from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
import PyQt5.Qt
from Pshape import *

class PnonCloseShape(Pshape):
    def __init__(self):
        super(PnonCloseShape,self).__init__()



